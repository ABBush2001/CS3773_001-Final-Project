<?php
require_once 'loaditems.php';
require_once 'userinstance.php';
require_once 'items.php';
require_once 'loadUser.php';
session_start();
$id = $_GET['id'];
$item = loadItem($id);

$user = null;
if(isset($_SESSION['userID'])==FALSE && $_SESSION['userID']  != "guest")
{
  	$user = new UserInstance("guest","guest","guest","none","none","none",0);
	$_SESSION['userID'] = $user->getUName();
}else{
    $usr = $_SESSION['userID'];
	if($_SESSION['userID'] != "guest") {
		$user = loadUser($usr);
	}else{
		$user = new UserInstance("guest","guest","guest","none","none","none",0);
	}
}
if(isset($_SESSION['cart'])==FALSE)
{
	$cart = array();
	$_SESSION['cart'] = $cart;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Art Central</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <link rel="stylesheet" href="CSS\productPage.css">
    <div class="menuBar" >
                <a href="index.php" style="font-size:10px">HOME</a>
            </div>
    <div class= "rightMenu">
                <a href="logIn.php">
                    <img src="images/userImage.png" width="95" height="50" style="right: 15px;position:fixed;float:right;image-orientation: flip;text-align: center;"/>
                </a>
                <a href="shoppingCart.php">
                    <img src="images/cart.png" width="50" height="50" style="right: 80px; position:fixed;float:right;image-orientation: flip;text-align: center;"/>
                </a>
                </div>
    <!--This is the login Icon, has a hyperlink that takes the user to the login screen-->

</head>
<body>

    <header>
        <h2>
			<?php
				echo $item->getName();
			?>
		</h2>
    </header>

    <section>
        <nav>
            <div class="test">
                <img src="<?php echo $item->getImg()?>" width="500" height="500" style="right:50px;" alt=""/>
                
            </div>
        </nav>

        <article>
            <?php

                if($item->getStock() == 0){
                    echo '<h1 style="color:red;">Product Amount: Item unavailable</h1>';
                }
                else{
                    echo '<h1 style="color:black;">Product Amount: '.$item->getStock().'</h1>';
                }
            ?>
            <h1>
				<?php
					echo 'Price $'.$item->getPrice();
				?>
			</h1>
            <p>Description</p>
            <p>
				<?php
					echo $item->getDescription();
				?>
			</p>
            <?php
                $itemArray = $_SESSION['cart'];
                $result = $_SESSION['cart'];

                $result= array_unique($result, SORT_REGULAR);
                $idArray = array();
                foreach($itemArray as $i) {
                    array_push($idArray, $i->getID());
                }
                $quantity = array_count_values($idArray);
                if(array_key_exists('button1', $_POST)){

                    if($item->getStock() > $quantity[$item->getID()]){
                        array_push($_SESSION['cart'], $item);
                        header("Refresh:0");
                    }else{
                        echo '<div class="alert alert-warning alert-dismissible">
                        <a href="shoppingCart.php" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Warning!</strong> Unable to add quantity: Exceeds stock availability.
                      </div>';
                    }
                    //echo "<script>console.log('test');</script>";
                }
                if($item->getStock() != 0) {
                    echo '<form method = "post">
                            <input type="submit" name= "button1" class ="button" value="Add to Cart"/>
                            </form>';
				}
            ?>

        </article>
    </section>
</body>
</html>
