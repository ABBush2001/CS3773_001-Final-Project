<?php
	echo "Item added to cart";
?>