<?php
function checkOut($item, $quantity) {
  require('databaseHandler.php');
  $stock = $item->getStock();
  $updatedStock = $stock-$quantity;
  $sql = "UPDATE products SET availability=$updatedStock WHERE itemId=".$item->getID().";";
  $item->setAvailability($updatedStock);
  if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
  } else {
    echo "Error updating record: " . $conn->error;
  }
}
