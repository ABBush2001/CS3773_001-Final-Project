<?php
function function_alert($message) {
      
    // Display the alert box 
    echo "<script type='text/javascript'>alert('$message');</script>";
}
?>