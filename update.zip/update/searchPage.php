<?php
require_once 'loaditems.php';
require_once 'userinstance.php';
require_once 'loadUser.php';
session_start();
$user=null;
$filter= $_GET['id'];
if(isset($_SESSION['userID'])==FALSE)
{
  	$user = new UserInstance("guest","guest","guest","none","none","none",0);
	$_SESSION['userID'] = $user->getUName();
}else{
    $usr = $_SESSION['userID'];
	if($_SESSION['userID'] != "guest") {
		$user = loadUser($usr);
	}else{
		$user = new UserInstance("guest","guest","guest","none","none","none",0);
	}
}
function displaySearch($itemArray){
    $count= (int)0;
    foreach($itemArray as $item){
        $count= $count + 1;
        if($count%5 == 0){
            echo '<tr></tr>';
        }
        if($_GET["search"] !== ""){
            if(stripos($item->getDescription(), $_GET["search"]) !== FALSE || stripos($item->getName(), $_GET["search"]) !== FALSE){
                echo '<td><a href= "productPage.php?id='.$item->getID().'"> <img src="' . $item->getImg() . '" style="row-gap: 100px; col-gap: 100px; display: block; align-items: center; justify-content: center" width="175%" height="175%"></img></a>'. $item->getDescription() . '</td>';
                echo '<script>console.log("worked");</script>';
            }
        }else{
            echo '<td><a href= "productPage.php?id='.$item->getID().'"> <img src="' . $item->getImg() . '" style="row-gap: 100px; col-gap: 100px; display: block; align-items: center; justify-content: center" width="175%" height="175%"></img></a>'. $item->getDescription() . '</td>';
            echo '<script>console.log("test");</script>';
        }
    }
}
function displayArtistSearch($itemArray){
    $count= (int)0;
    foreach($itemArray as $item){
        $count= $count + 1;
        if($count%5 == 0){
            echo '<tr></tr>';
        }
        if($_GET["search"] !== ""){
            if(stripos($item->getDescription(), $_GET["search"]) !== FALSE || stripos($item->getName(), $_GET["search"]) !== FALSE){
                if(strpos($item->getDescription(), $_GET["filters"])){
                    echo '<td><a href= "productPage.php?id='.$item->getID().'"> <img src="' . $item->getImg() . '" style="row-gap: 100px; col-gap: 100px; display: block; align-items: center; justify-content: center" width="175%" height="175%"></img></a>'. $item->getDescription() . '</td>';
                    echo '<script>console.log("worked");</script>';
                }
            }
        }else{
            if(strpos($item->getDescription(), $_GET["filters"])){
                echo '<td><a href= "productPage.php?id='.$item->getID().'"> <img src="' . $item->getImg() . '" style="row-gap: 100px; col-gap: 100px; display: block; align-items: center; justify-content: center" width="175%" height="175%"></img></a>'. $item->getDescription() . '</td>';
                echo '<script>console.log("worked");</script>';
            }
        }
    }
}
?>

<!DOCTYPE html>
    <html>
        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="CSS\searchPage.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

            <title>Art Central</title>
            <div class="menu" >
                <a href="index.php" style="font-size:10px">HOME</a>
                <form action="/searchPage.php">
                    <input type="text" placeholder="Search..." name="search" value="<?php
                    echo $_GET['search'];
                    ?>">
                    <button type="submit"><i class="fa fa-search"></i></button>
                    <select class="table-filter" name="filters">
                        <option value="all">No filter selected</option>
                        <option value="lowHigh">Sort by price (low to high)</option>
                        <option value="highLow">Sort by price (high to low)</option>
                        <option value="lowAvail">Sort by availability (low to high)</option>
                        <option value="highAvail">Sort by availability (high to low)</option>
                        <optgroup label="Artists">
                            <?php
                                $itemArray = loadItems();
                                $artistArray= array();
                                $position = 0;
                                foreach($itemArray as $item){
                                    for($i=0; $i<strlen($item->getDescription()); $i++){
                                        if($item->getDescription()[$i]== '['){
                                            $position = $i+1;
                                        }else if($item->getDescription()[$i] == ']'){
                                            array_push($artistArray, substr($item->getDescription(), $position, $i-$position));
                                        }
                                    }
                                }
                                $artistArray= array_unique($artistArray);
                                foreach($artistArray as $artist){
                                    echo '<option value="'.$artist.'">'.$artist.'</option>';
                                }
                            ?>

                        </optgroup>
                    </select>
                </form>
            </div>
            <div class= "rightMenu">
                <a href="logIn.php">
                    <img src="images/userImage.png" width="95" height="50" style="right: 15px;position:fixed;justify-content: flex-end;image-orientation: flip;text-align: center;"/>
                </a>
                <a href="shoppingCart.php">
                    <img src="images/cart.png" width="50" height="50" style="right: 80px; position:fixed;justify-content: flex-end;image-orientation: flip;text-align: center;"/>
                </a>
                <?php
					if($user != null && $user->getUName() != "guest" )
					{
						echo '<form method = "post">
		                    <input type ="submit" name = "logout" class = "extendedProfile" value = "Log out" style="top: 80px; right: 30px; position:fixed;justify-content: flex-end;image-orientation: flip;text-align: center;"/>
		                </form>';
					}
                    if(array_key_exists('logout', $_POST)){
                        unset($_SESSION['userID']);
                        unset($_POST['uname']);
                        unset($_POST['psw']);
						header("Refresh:0");
                    }
                ?>
                </div>
        </head>
        <body>
            <h1>Showing results of "<?php
                if($_GET["search"] !== ""){
                    echo $_GET["search"];
                }
            
            ?>"
            <table class="artTable" style="width:50%">
                <tr>
                    
                    <?php
                        if(isset($_GET["filters"])){
                            echo "uhhhhhh";
                        }
                        
                        $itemArray = loadItems();
                        switch($filter){
                            case 'all':
                                displaySearch($itemArray);
                                break;
                            case 'lowHigh':
                                usort($itemArray,function($first,$second){
                                    return $first->getPrice() > $second->getPrice();
                                });
                                displaySearch($itemArray);
                                break;
                            case 'highLow':
                                usort($itemArray,function($first,$second){
                                    return $first->getPrice() < $second->getPrice();
                                });
                                displaySearch($itemArray);
                                break;
                            case 'lowAvail':
                                usort($itemArray,function($first,$second){
                                    return $first->getStock() > $second->getStock();
                                });
                                displaySearch($itemArray);
                                break;
                            case 'highAvail':
                                usort($itemArray,function($first,$second){
                                    return $first->getStock() < $second->getStock();
                                });
                                displaySearch($itemArray);
                                break;
                            default:
                                displayArtistSearch($itemArray);
                        }
                        
                        $_GET["search"] = $_GET["search"];
                        echo '<script>console.log("'.$_GET["search"].'");</script>';
                        
                    ?>
                    

        </body>
    </html>
